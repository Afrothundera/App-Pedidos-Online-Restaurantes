package com.opdeveloper.pedidos.welcome

import android.content.Intent
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import com.opdeveloper.pedidos.R
import com.opdeveloper.pedidos.signin.SignInActivity
import kotlinx.android.synthetic.main.activity_welcome.*

class WelcomeActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        auth = FirebaseAuth.getInstance()
        val face : Typeface = Typeface.createFromAsset(assets, "fonts/NABILA.TTF")

        txtSlogan.typeface = face

        btnSignUp.setOnClickListener {

        }

        btnSignIn.setOnClickListener {
            val intent = Intent(this@WelcomeActivity, SignInActivity::class.java)
            startActivity(intent)
        }
    }

    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        /*if (currentUser!!.email != null) {
            val intent = Intent(this@WelcomeActivity, SignInActivity::class.java)
            startActivity(intent)
        }*/
    }
}
